import boto3
import os
def lambda_handler(event, context):
    ses = boto3.client('ses', region_name='us-east-1')
    email = os.environ['EMAIL_ADDRESS']
    try:
        response = ses.send_email(
            Source=email,
            Destination={'ToAddresses': [email]},
            Message={
                'Subject': {'Data': 'Terraform State File Alert!'},
                'Body': {'Text': {'Data': 'The terraform.tfstate file in your S3 bucket has been modified.'}}
            }
        )
        return {"statusCode": 200, "body": "Email sent!"}
    except Exception as e:
        print(e)
        return {"statusCode": 500, "body": str(e)}
